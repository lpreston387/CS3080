##”””
##Homework 5, Exercise 3
##Name Leonard Preston
##Date 3/23/2023
##Generator range function
##”””


#Defining a gen
def gen_range(stop,start =0, step = 1):
    index = start
    while index < stop:
        yield index
        index = index + step


def main():

    #Getting start and stop
    print("Choose a start")
    start = int(input())
    print("Choose a stop")
    stop = int(input())

    #Printing using a generator
    for x in gen_range(stop,start):
        print(x)

main()
