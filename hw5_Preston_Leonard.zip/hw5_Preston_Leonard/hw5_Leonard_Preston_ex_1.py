##”””
##Homework 5, Exercise 1
##Name Leonard Preston
##Date 3/23/2023
##Creating a psuedo reverse iteration class
##”””

class ReverseIter:

    #Constructor
    def __init__(self, list):
        print("inside constructor")
        
        #Setting list
        self.list = list

        #Setting length of incoming list
        self.length = len(self.list)

    #next
    def __next__(self):

        #prevent list count from going below 0
        try:
            if(self.length > 0):
                print(self.list[self.length - 1])
            
        #decrementing list
            self.length = self.length - 1
            

            
        except StopIteration:
            print("Stop iteration error! exiting program")
            exit()
            
        
        



def main():
    myList = ReverseIter([1, 2, 3 ,4 ,5])
    next(myList)
    next(myList)
    next(myList)
    next(myList)
    next(myList)
    next(myList)
    next(myList)



main()
        





