##Homework 4, Exercise 2
##Name Leonard Preston
##Date 3/9/2023
##Find phone numbers and email addresses from clip board.


import re

#Clipboard
string = ("asfhkjlhfdaklfjhlk 333-333-3333 sdfd@sfdsf 222-222-2222 sdasdas 23@gmail.com hello@gmail.com taco@sss.com")

#Phone numbers
phoneNumRegex = re.findall(r'\d{3}-\d{3}-\d{4}', string)

#Emails
# .\S+ .com .edu etc
# \S + @ allows letters numbers _ before @
# + just concats the search results together
emailRegex = re.findall(r'\S+@\S+\.\S+', string)


print(phoneNumRegex)
print(emailRegex)


