#”””
#Homework 4, 3
#Name Leonard Preston
#Date 3/9/2023
#Strong password using regex.
#”””


import re

print("Enter password")
x= input()

# {8,} sets min length at 8
# Upper, Lower, and numbers allowed
if re.match(r'[A-Za-z0-9]{8,}', x):
    print ("Strong password")
else:
    print ("Not a strong password")

    
            
