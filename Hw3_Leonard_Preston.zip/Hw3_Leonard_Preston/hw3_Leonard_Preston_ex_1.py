##””” 
##Homework 3, Exercise 1 
##Name Leonard Preston
##Date 2/23/2023
##Automate the boring stuff, page 103 Character picture guide
##”””


grid = [['.', '.', '.', '.', '.', '.'], 
['.', 'O', 'O', '.', '.', '.'], 
['O', 'O', 'O', 'O', '.', '.'], 
['O', 'O', 'O', 'O', 'O', '.'], 
['.', 'O', 'O', 'O', 'O', 'O'], 
['O', 'O', 'O', 'O', 'O', '.'], 
['O', 'O', 'O', 'O', '.', '.'], 
['.', 'O', 'O', '.', '.', '.'], 
['.', '.', '.', '.', '.', '.']]

##Variables
startingPoint = grid[0]
colRange = range(len(startingPoint))
rowRange = range(len(grid))


# Iterating through cols
for col in colRange:
    print()
    #Iterating through rows
    for row in rowRange:
        # end = "" prevents each row from being print
        # on a seperate line
        print(grid[row][col], end = "")


