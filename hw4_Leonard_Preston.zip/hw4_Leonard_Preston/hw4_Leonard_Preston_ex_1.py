##”””
##Homework 4, Exercise 1 (
##Name Leonard Preston        
##Date 3/9/2023
##Square/Rectangle/Circle Classes
##”””
import math

class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def areaRectangle(self):
        return self.length*self.width

    def diagonalRectangle(self):
        return math.sqrt((self.length*self.length)+(self.width*self.width))
        

class Square:
    def _init_(length):
        self.length = length

    def areaSquare(self):
        return self.length*self.length

    def diagonalSquare(self):
        return self.length*math.sqrt(2)

    def perimeterSquare():
        return self.length + self.length + self.length + self.length
        
        

class Circle:
    def __init__(self, radius):
        self.radius = radius

    def areaCircle(self):
        return math.pi*(2*self.radius)

    def diameterCircle(self):
        return 2*(self.radius)

    def perimeterCircle(self):
    
        return 2*math.pi*self.radius
           

    

def main():
    myRectangle = Rectangle(20, 10)

    #get diagnol of rectangle
    rDiagonal = myRectangle.diagonalRectangle()

    #half of diagnol
    rDiagonal = rDiagonal/2

    #Creating a circle
    myCircle = Circle(rDiagonal)

    # Calculating perimeter
    cPerimeter = myCircle.perimeterCircle()

    # printing perimeter of a circle
    print(cPerimeter)

    
    
main()
    

