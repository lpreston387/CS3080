##Homework 3, Exercise 3  
##Name Leonard Preston
##Date 2/23/2023
##Tic Tac Toe. Playing with dictionaries
##

# Display the dictionary
def displayDict(board):
    print("  1 2 3")
    print("A", board["A1"] + " " + board["A2"] + " " + board["A3"])
    print("B", board["B1"] + " " + board["B2"] + " " + board["B3"])
    print("C", board["C1"] + " " + board["C2"] + " " + board["C3"])


        
                

#Create a dictionary
board = {'A1': '*', 'A2': '*', 'A3': '*',
            'B1': '*', 'B2': '*', 'B3': '*',
            'C1': '*', 'C2': '*', 'C3': '*'}




#Variables

# Dictates the players turn
count = 0
# picks is a list used to validate user input
picks = [ "A1", "B1", "C1", "A2", "B2", "C2", "A3", "B3", "C3"]
finished = True # False when game is finished or a player quits


# Play until finished = false
while finished:
    #displays board after every turn
    displayDict(board)
    print("Choices:", picks)
    if count % 2 == 0:
        print()
        print("Player one pick a spot or type 'exit' to quit.")
        pick = input()
        pick = pick.upper()

        # Validation loop 
        for x in picks:
            if x == pick:
                print()
                print("You chose", pick)
                picks.remove(x) #Remove pick from possible choices
                board[pick] = "X" #replaces a * in the dictionary


            elif pick == "exit":
                finished = False

   
    #Same as above if statement but for player 2      
    elif count % 2 != 0:
        print()
        print("Player two pick a spot or type 'exit' to quit.")
        pick = input()
        pick = pick.upper()
        for x in picks:
            if x == pick:
                print()
                print("You chose", pick)
                picks.remove(x)
                board[pick] = "O"
            elif pick == "exit":
                finished = False


    count = count + 1
    if count == 9:
        finished = False
                
print (" \n Result")
displayDict(board)
        
    
