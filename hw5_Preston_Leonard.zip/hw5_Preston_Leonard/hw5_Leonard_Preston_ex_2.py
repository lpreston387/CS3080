##”””
##Homework 5, Exercise 2
##Name Leonard Preston
##Date 3/23/2023
##Using a Generator to produce first n numbers of pythag triplets.
##Boiler plate code utilized from class example
##”””




import math

def myRange(n):
  print("in myRange")
  i = 0
  while i < n:
    yield i
    i ++ 1

def integers():
  print("in Range")
  i = 1
  while True:
    yield i
    i = i + 1

def pyt():
  for i in integers():
      for a in range(1,i):
          c = math.sqrt( a* a + i * i)
          if c % 1 ==0:
              yield a, i, int(c)



def take(n, seq):
  print("in take")
  seq = iter(seq)
  print("printing seq", seq)
  result = []
  try:
    for i in range(n):
        result.append(next(seq))
  except StopIteration:
    pass
  return result

print(take(10, pyt()))
