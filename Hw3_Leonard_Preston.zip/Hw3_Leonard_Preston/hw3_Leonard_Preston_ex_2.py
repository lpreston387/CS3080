##””” 
##Homework 3, Exercise 2 
##Name Leonard Preston
##Date 2/23/2023
##Number of occurrences in a string using dictionaries
##”””

import pprint

myString = "The quick brown fox jumps over the lazy dog."

##Variables
count = 0 #Tracker

##Creating Dictionary
myDict = {}

# x is the search element
for x in myString:
    count = 0
    x = x.lower()

    # x will match verse every element of y 
    for y in myString:
        y = y.lower()
        if x == y:
            count = count + 1
    myDict[x] = count

## Displaying dictionary
pprint.pprint(myDict) 

    

